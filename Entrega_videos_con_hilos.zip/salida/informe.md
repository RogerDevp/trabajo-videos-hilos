# Generación de video con hilos en Python

## 1. Objetivo

Implementar y analizar un programa Python que produzca un video narrado con subtítulos y música, utilizando hilos para la preparación de imágenes, la síntesis de voz y el renderizado independiente de escenas. Estudiante: ____________________. Docente: ____________________. Entrega: 28/10/2026, 18:00 (Perú).

## 2. Entradas y resultado

El proyecto utiliza seis pares existentes: image/basic contiene las versiones anime y image/realistic las versiones realistas. configuracion.json establece la correspondencia explícita y evita emparejar imágenes por orden alfabético. Cada fase se muestra como anime y luego como realista; el ciclo se repite en la siguiente fase. La salida es 1080x1920, relación 9:16, 30 FPS y 42.03 segundos, con video H.264, audio AAC, subtítulos grabados y una pista SRT adicional. Los originales no se modifican. El encuadre elimina en memoria la franja inferior de los PNG con títulos antiguos; en anime se quita el blanco conectado al borde para integrar al personaje en el fondo. La transición usa magnitud de gradientes Sobel para revelar detalles, sin generar imágenes nuevas ni deformar los rostros.

## 3. Descomposición del trabajo

El programa tiene tres lotes concurrentes y dos etapas de ensamblaje secuenciales. (1) Cada tarea de imágenes prepara un par anime/realista y devuelve matrices. (2) Cada tarea de voz devuelve las muestras PCM de una intervención. (3) Cada tarea de render produce un MP4 independiente. Después se concatenan los MP4 según la línea de tiempo y se mezcla el audio. La separación evita que dos hilos escriban en el mismo codificador o alteren el orden de fotogramas.

## 4. Preparación concurrente de imágenes

ThreadPoolExecutor limita la concurrencia mediante max_workers. executor.map distribuye funciones y devuelve resultados en el orden de entrada. A diferencia del ejemplo del PDF, se entrega una función ejecutable al planificador y se recogen sus resultados. No se ejecuta anticipadamente la función dentro de target. Cada tarea construye sus propias matrices; después se comparten para lectura.

```python
with ThreadPoolExecutor(max_workers=a.workers,
                        thread_name_prefix="imagenes") as pool:
    phases = list(pool.map(
        lambda item: prepare_phase(item, a.images, size),
        cfg["fases"]))
```

## 5. Renderizado de escenas en paralelo

Se crearon 14 tareas de render y se permitió un máximo de 4 trabajadores. render_segment recibe el índice, la escena, las imágenes y los parámetros de codificación. Cada trabajador abre su proceso FFmpeg, escribe cuadros consecutivos por una tubería privada y guarda un segmento con nombre numérico. FFmpeg usa un hilo por proceso para reducir la multiplicación de hilos internos. OpenCV también se limita a un hilo interno. El orden de finalización puede ser distinto del orden narrativo.

```python
tasks = [(i, s, phases, segments, w, h, a.fps, epoch)
         for i, s in enumerate(scenes)]
with ThreadPoolExecutor(max_workers=a.workers,
                        thread_name_prefix="render") as pool:
    events = list(pool.map(render_segment, tasks))
# events conserva el orden de tasks, no el de finalizacion.
lista = "".join(f"file '{e["archivo"]}'\n" for e in events)
```

## 6. Sincronización, exclusión y errores

La salida de cada hilo tiene un archivo diferente: segmentos/000.mp4, 001.mp4, etc. Por ello no se necesita un Lock para un VideoWriter compartido. El hilo principal construye la lista de concatenación solo después de completar list(pool.map(...)); esta recolección funciona como barrera. Las excepciones de los trabajadores se propagan al hilo principal. Cada proceso cierra su entrada en finally, se espera su salida y se comprueba su código de retorno. Los registros FFmpeg se guardan por segmento. Las matrices preparadas se leen sin modificarlas; cada fotograma transformado pertenece al trabajador que lo escribe.

```python
try:
    for n in range(scene["frames"]):
        frame = render(...)
        proc.stdin.write(frame.tobytes())
finally:
    proc.stdin.close()
    code = proc.wait()
if code:
    raise RuntimeError("Error de render de la escena")
```

## 7. Reloj de video, voz y subtítulos

timeline calcula la duración de cada escena a partir de la longitud de voz y redondea hacia arriba a fotogramas completos. El cursor global es un entero de fotogramas. La cantidad de muestras PCM se obtiene restando límites absolutos redondeados, lo que evita acumular errores al concatenar. Se dejan 0.12 s antes de cada intervención y al menos 0.22 s después. El mismo intervalo se utiliza al dibujar subtítulos y escribir el SRT. La sincronización es por intervención, no por palabra. Motor usado: edge, voz es-PE-AlexNeural. La síntesis se ejecuta con hasta tres trabajadores y utiliza caché por texto/voz. El modo automático puede recurrir a eSpeak si falla el servicio de voz. La música se atenúa durante la narración y se limita la amplitud final.

```python
start = cursor / fps
count = (round((cursor + frames) / fps * RATE)
         - round(cursor / fps * RATE))
chunk = np.zeros(count, dtype=np.float32)
offset = round(0.12 * RATE)
chunk[offset:offset + len(voice)] = voice
cursor += frames
```

## 8. Comparación secuencial y concurrente

Se midió exclusivamente la preparación de los mismos seis pares, con el mismo tamaño y los mismos algoritmos. Se realizó un calentamiento previo y tres repeticiones por método, alternando el orden. Se reporta la mediana para reducir la influencia de una medición atípica. La creación y cierre del pool están incluidos en Tp. T1 = 6.039 s; Tp = 2.991 s. Aceleración S = T1/Tp = 2.019. Eficiencia E = S/4 = 50.5 %. La preparación concurrente fue más rápida en esta ejecución. Este cociente no mide la aceleración del video completo. Cachés, carga del equipo, ancho de banda de memoria y tamaño del lote afectan el resultado.

| Repetición | Secuencial (s) | Hilos (s) |
|---|---|---|
| 1 | 4.419 | 3.504 |
| 2 | 6.899 | 2.991 |
| 3 | 6.039 | 2.972 |
## 9. Evidencia de concurrencia del render

Preparación de producción: 2.65 s. Lote de voz: 0.00 s (puede usar caché). Render de escenas: 53.16 s. Tiempo hasta terminar el video: 85.09 s, incluye el benchmark cuando está habilitado y excluye la elaboración del informe. Máximo observado: 4 tareas de render con intervalos superpuestos. Los tiempos provienen de perf_counter al entrar y salir de cada tarea. Esta evidencia demuestra concurrencia; no demuestra por sí sola ejecución simultánea de instrucciones Python ni aceleración frente a una ejecución secuencial completa.

![Figura 1. Intervalos de los trabajadores. Los números identifican las escenas.](capturas/hilos.png)

## 10. GIL, memoria y límites

En Python los hilos no garantizan paralelismo de código Python por las restricciones del intérprete; OpenCV, NumPy y Pillow ejecutan operaciones nativas, y cada FFmpeg es un proceso externo que puede trabajar en otro núcleo. La voz también puede beneficiarse del solapamiento de esperas de red. Aumentar workers sin límite puede empeorar el rendimiento por contención de CPU, memoria o disco. No se almacena el video completo en RAM: cada hilo genera y envía un fotograma a la vez, aunque mantiene las matrices de los pares y búferes temporales. Los segmentos se conservan en disco como evidencia y para depuración. Una comparación rigurosa del render total requeriría repetir la misma carga con workers=1 y workers=N, bajo condiciones comparables.

## 11. Ejecución y verificación reproducible

Instalar requirements.txt, FFmpeg, eSpeak NG y DejaVu Sans. Ejecutar: python generar_video.py --benchmark --demo-music. Cambiar --workers para controlar el tamaño de los pools y --height 1280 para reducir el costo de render. Ejecutar las pruebas con python -m unittest discover -s tests -v. Inspeccionar pistas y duración con ffprobe y decodificar todo el MP4 con ffmpeg -v error -i salida/goku_narrado.mp4 -f null -. metadatos.json contiene las mediciones, los índices, los hilos y los intervalos que permiten revisar este informe. Las pruebas cubren correspondencia entre pares, extremos de transición, reloj PCM y recolección ordenada de tareas.

## 12. Enlace de YouTube

PENDIENTE: añadir enlace de YouTube

## 13. Conclusión

La solución aplica descomposición por datos y por escenas. El paralelismo del render se realiza mediante trabajadores Python que coordinan codificadores independientes; el ensamblaje final mantiene el orden narrativo. Se evita escribir concurrentemente en un único archivo y se usa una línea de tiempo común para audio y video. Los resultados medidos se distinguen de las expectativas teóricas: la concurrencia observada no se presenta como aceleración no medida.

## Referencias

Guías del curso conservadas en referencias/: “5 genera videos con IA e hilos.pdf” y “5 VIDEOS con IA.pdf”. Biblioteca estándar Python: https://docs.python.org/3/library/concurrent.futures.html . FFmpeg: https://ffmpeg.org/ffmpeg-formats.html#concat y https://ffmpeg.org/ffmpeg-filters.html . Edge TTS: https://github.com/rany2/edge-tts .

## Anexo. Capturas del video vertical

Capturas extraídas del MP4 final. Cada pareja presenta la imagen anime suministrada y su versión realista correspondiente.

![Anime](capturas/01_anime_base.png)
![Realista](capturas/02_realista_base.png)
Pareja 1: GOKU BASE. Anime a la izquierda; realista a la derecha.

![Anime](capturas/03_anime_ssj3.png)
![Realista](capturas/04_realista_ssj3.png)
Pareja 2: SUPER SAIYAJIN 3. Anime a la izquierda; realista a la derecha.

![Anime](capturas/05_anime_dios.png)
![Realista](capturas/06_realista_dios.png)
Pareja 3: SUPER SAIYAJIN DIOS. Anime a la izquierda; realista a la derecha.
