"""Informe de computación paralela con código, mediciones y capturas del reel."""
import argparse
from html import escape
import json
from pathlib import Path
import subprocess


def concurrency_chart(events,path):
    from PIL import Image,ImageDraw,ImageFont
    im=Image.new('RGB',(1100,420),'white');d=ImageDraw.Draw(im)
    from generar_video import font
    workers=sorted({e['hilo'] for e in events});total=max(e['fin_s'] for e in events)
    d.text((25,15),'Renderizado concurrente: intervalos observados',font=font(25,True),fill='#122033')
    palette=['#E58129','#207FAB','#A44475','#488452','#7664C4','#147D76']
    for i,worker in enumerate(workers):
        y=80+i*(270/max(len(workers),1))
        d.text((20,y+10),worker,font=font(18),fill='#25354A')
        d.line((180,y+40,1050,y+40),fill='#DCE1E8')
        for e in events:
            if e['hilo']!=worker:continue
            x0=180+e['inicio_s']/total*870;x1=180+e['fin_s']/total*870
            d.rectangle((x0,y,x1,y+36),fill=palette[i%len(palette)])
            d.text((x0+4,y+8),str(e['index']+1),font=font(16,True),fill='white')
    for i in range(6):
        x=180+i/5*870;d.text((x-10,365),f'{i/5*total:.1f}s',font=font(16),fill='#25354A')
    d.text((180,395),'Cada bloque representa una escena. El solapamiento indica tareas activas.',font=font(16),fill='#25354A')
    im.save(path)


def generar_informe(out,youtube=None):
    from docx import Document
    from docx.shared import Inches,Pt
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image,PageBreak,Table,TableStyle,Preformatted,KeepTogether
    m=json.loads((out/'metadatos.json').read_text(encoding='utf-8'))
    if youtube:
        m['youtube']=youtube
        (out/'metadatos.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
    caps=out/'capturas';caps.mkdir(exist_ok=True)
    scenes=m['escenas']
    samples=[('01_anime_base',1),('02_realista_base',2),('03_anime_ssj3',7),
             ('04_realista_ssj3',8),('05_anime_dios',11),('06_realista_dios',12)]
    for name,idx in samples:
        scene=scenes[idx];stamp=scene['start']+min(1.0,scene['duration']/2)
        subprocess.run(['ffmpeg','-v','error','-y','-ss',str(stamp),'-i',str(out/'goku_narrado.mp4'),
           '-frames:v','1','-update','1',str(caps/f'{name}.png')],check=True)
    concurrency_chart(m['eventos_render'],caps/'hilos.png')
    styles=getSampleStyleSheet()
    styles['BodyText'].leading=14;styles['BodyText'].spaceAfter=10
    styles['Heading1'].keepWithNext=True;styles['Heading2'].keepWithNext=True
    styles.add(ParagraphStyle('Codigo',fontName='Courier',fontSize=7.7,leading=10,backColor=colors.HexColor('#F1F4F8'),spaceAfter=12))
    story=[];doc=Document();md=[]
    doc.add_heading('Generación de video con hilos en Python',0)
    doc.add_paragraph('Computación Paralela · UNAP\nReel vertical: Goku, anime y realismo')
    story.extend([Paragraph('Generación de video con hilos en Python',styles['Title']),
                  Paragraph('Computación Paralela · Reel vertical: Goku, anime y realismo',styles['Heading2'])])
    md+=['# Generación de video con hilos en Python','']
    def section(title,text):
        story.extend([Paragraph(escape(title),styles['Heading2']),Paragraph(escape(text),styles['BodyText'])])
        doc.add_heading(title,level=1);doc.add_paragraph(text);md.extend(['## '+title,'',text,''])
    def code(text):
        story.append(Preformatted(text,styles['Codigo']))
        para=doc.add_paragraph();r=para.add_run(text);r.font.name='Consolas';r.font.size=Pt(8)
        md.extend(['```python',text,'```',''])
    def picture(path,width,height,caption):
        story.append(KeepTogether([Image(str(path),width=width,height=height),Paragraph(escape(caption),styles['BodyText'])]))
        doc.add_picture(str(path),width=Inches(width/72));doc.add_paragraph(caption)
        md.extend([f'![{caption}](capturas/{path.name})',''])
    section('1. Objetivo',
      'Implementar y analizar un programa Python que produzca un video narrado con subtítulos y música, '
      'utilizando hilos para la preparación de imágenes, la síntesis de voz y el renderizado independiente de escenas. '
      'Estudiante: ____________________. Docente: ____________________. Entrega: 28/10/2026, 18:00 (Perú).')
    section('2. Entradas y resultado',
      'El proyecto utiliza seis pares existentes: image/basic contiene las versiones anime y image/realistic las versiones realistas. '
      'configuracion.json establece la correspondencia explícita y evita emparejar imágenes por orden alfabético. '
      'Cada fase se muestra como anime y luego como realista; el ciclo se repite en la siguiente fase. '
      f'La salida es {m["resolucion"]}, relación 9:16, {m["fps"]} FPS y {m["duracion_s"]:.2f} segundos, '
      'con video H.264, audio AAC, subtítulos grabados y una pista SRT adicional. '
      'Los originales no se modifican. El encuadre elimina en memoria la franja inferior de los PNG con títulos antiguos; '
      'en anime se quita el blanco conectado al borde para integrar al personaje en el fondo. '
      'La transición usa magnitud de gradientes Sobel para revelar detalles, sin generar imágenes nuevas ni deformar los rostros.')
    section('3. Descomposición del trabajo',
      'El programa tiene tres lotes concurrentes y dos etapas de ensamblaje secuenciales. '
      '(1) Cada tarea de imágenes prepara un par anime/realista y devuelve matrices. '
      '(2) Cada tarea de voz devuelve las muestras PCM de una intervención. '
      '(3) Cada tarea de render produce un MP4 independiente. '
      'Después se concatenan los MP4 según la línea de tiempo y se mezcla el audio. '
      'La separación evita que dos hilos escriban en el mismo codificador o alteren el orden de fotogramas.')
    section('4. Preparación concurrente de imágenes',
      'ThreadPoolExecutor limita la concurrencia mediante max_workers. executor.map distribuye funciones y devuelve resultados '
      'en el orden de entrada. A diferencia del ejemplo del PDF, se entrega una función ejecutable al planificador y se recogen sus resultados. '
      'No se ejecuta anticipadamente la función dentro de target. Cada tarea construye sus propias matrices; después se comparten para lectura.')
    code('with ThreadPoolExecutor(max_workers=a.workers,\n'
         '                        thread_name_prefix="imagenes") as pool:\n'
         '    phases = list(pool.map(\n'
         '        lambda item: prepare_phase(item, a.images, size),\n'
         '        cfg["fases"]))')
    section('5. Renderizado de escenas en paralelo',
      f'Se crearon {len(scenes)} tareas de render y se permitió un máximo de {m["workers"]} trabajadores. '
      'render_segment recibe el índice, la escena, las imágenes y los parámetros de codificación. '
      'Cada trabajador abre su proceso FFmpeg, escribe cuadros consecutivos por una tubería privada y guarda un segmento con nombre numérico. '
      'FFmpeg usa un hilo por proceso para reducir la multiplicación de hilos internos. OpenCV también se limita a un hilo interno. '
      'El orden de finalización puede ser distinto del orden narrativo.')
    code('tasks = [(i, s, phases, segments, w, h, a.fps, epoch)\n'
         '         for i, s in enumerate(scenes)]\n'
         'with ThreadPoolExecutor(max_workers=a.workers,\n'
         '                        thread_name_prefix="render") as pool:\n'
         '    events = list(pool.map(render_segment, tasks))\n'
         '# events conserva el orden de tasks, no el de finalizacion.\n'
         'lista = "".join(f"file \'{e[\"archivo\"]}\'\\n" for e in events)')
    section('6. Sincronización, exclusión y errores',
      'La salida de cada hilo tiene un archivo diferente: segmentos/000.mp4, 001.mp4, etc. '
      'Por ello no se necesita un Lock para un VideoWriter compartido. El hilo principal construye la lista de concatenación '
      'solo después de completar list(pool.map(...)); esta recolección funciona como barrera. '
      'Las excepciones de los trabajadores se propagan al hilo principal. Cada proceso cierra su entrada en finally, '
      'se espera su salida y se comprueba su código de retorno. Los registros FFmpeg se guardan por segmento. '
      'Las matrices preparadas se leen sin modificarlas; cada fotograma transformado pertenece al trabajador que lo escribe.')
    code('try:\n'
         '    for n in range(scene["frames"]):\n'
         '        frame = render(...)\n'
         '        proc.stdin.write(frame.tobytes())\n'
         'finally:\n'
         '    proc.stdin.close()\n'
         '    code = proc.wait()\n'
         'if code:\n'
         '    raise RuntimeError("Error de render de la escena")')
    section('7. Reloj de video, voz y subtítulos',
      'timeline calcula la duración de cada escena a partir de la longitud de voz y redondea hacia arriba a fotogramas completos. '
      'El cursor global es un entero de fotogramas. La cantidad de muestras PCM se obtiene restando límites absolutos redondeados, '
      'lo que evita acumular errores al concatenar. Se dejan 0.12 s antes de cada intervención y al menos 0.22 s después. '
      'El mismo intervalo se utiliza al dibujar subtítulos y escribir el SRT. La sincronización es por intervención, no por palabra. '
      f'Motor usado: {m["tts"]}, voz {m["voz"]}. La síntesis se ejecuta con hasta tres trabajadores y utiliza caché por texto/voz. '
      'El modo automático puede recurrir a eSpeak si falla el servicio de voz. La música se atenúa durante la narración y se limita la amplitud final.')
    code('start = cursor / fps\n'
         'count = (round((cursor + frames) / fps * RATE)\n'
         '         - round(cursor / fps * RATE))\n'
         'chunk = np.zeros(count, dtype=np.float32)\n'
         'offset = round(0.12 * RATE)\n'
         'chunk[offset:offset + len(voice)] = voice\n'
         'cursor += frames')
    b=m.get('benchmark')
    if b:
        section('8. Comparación secuencial y concurrente',
          'Se midió exclusivamente la preparación de los mismos seis pares, con el mismo tamaño y los mismos algoritmos. '
          'Se realizó un calentamiento previo y tres repeticiones por método, alternando el orden. '
          'Se reporta la mediana para reducir la influencia de una medición atípica. La creación y cierre del pool están incluidos en Tp. '
          f'T1 = {b["T1_s"]:.3f} s; Tp = {b["Tp_s"]:.3f} s. '
          f'Aceleración S = T1/Tp = {b["speedup"]:.3f}. Eficiencia E = S/{m["workers"]} = {b["eficiencia"]*100:.1f} %. '
          +('La preparación concurrente fue más rápida en esta ejecución. ' if b['speedup']>1 else 'La preparación concurrente no fue más rápida en esta ejecución. ')
          +'Este cociente no mide la aceleración del video completo. Cachés, carga del equipo, ancho de banda de memoria y tamaño del lote afectan el resultado.')
        rows=[['Repetición','Secuencial (s)','Hilos (s)']]+[[str(i+1),f'{s:.3f}',f'{p:.3f}'] for i,(s,p) in enumerate(zip(b['muestras_s']['secuencial'],b['muestras_s']['hilos']))]
        table=Table(rows,colWidths=[130,150,150]);table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E5ECF5')),('GRID',(0,0),(-1,-1),.5,colors.lightgrey),('PADDING',(0,0),(-1,-1),8)]));story.append(table)
        t=doc.add_table(rows=0,cols=3);t.style='Table Grid'
        for row in rows:
            for c,v in zip(t.add_row().cells,row):c.text=v
        md+=['| Repetición | Secuencial (s) | Hilos (s) |','|---|---|---|']+['| '+' | '.join(r)+' |' for r in rows[1:]]
    section('9. Evidencia de concurrencia del render',
      f'Preparación de producción: {m["preparacion_s"]:.2f} s. Lote de voz: {m["voz_s"]:.2f} s (puede usar caché). '
      f'Render de escenas: {m["render_s"]:.2f} s. Tiempo hasta terminar el video: {m["tiempo_total_s"]:.2f} s, '
      'incluye el benchmark cuando está habilitado y excluye la elaboración del informe. '
      f'Máximo observado: {m["max_tareas_simultaneas"]} tareas de render con intervalos superpuestos. '
      'Los tiempos provienen de perf_counter al entrar y salir de cada tarea. Esta evidencia demuestra concurrencia; '
      'no demuestra por sí sola ejecución simultánea de instrucciones Python ni aceleración frente a una ejecución secuencial completa.')
    picture(caps/'hilos.png',480,183,'Figura 1. Intervalos de los trabajadores. Los números identifican las escenas.')
    section('10. GIL, memoria y límites',
      'En Python los hilos no garantizan paralelismo de código Python por las restricciones del intérprete; '
      'OpenCV, NumPy y Pillow ejecutan operaciones nativas, y cada FFmpeg es un proceso externo que puede trabajar en otro núcleo. '
      'La voz también puede beneficiarse del solapamiento de esperas de red. Aumentar workers sin límite puede empeorar el rendimiento '
      'por contención de CPU, memoria o disco. No se almacena el video completo en RAM: cada hilo genera y envía un fotograma a la vez, '
      'aunque mantiene las matrices de los pares y búferes temporales. Los segmentos se conservan en disco como evidencia y para depuración. '
      'Una comparación rigurosa del render total requeriría repetir la misma carga con workers=1 y workers=N, bajo condiciones comparables.')
    section('11. Ejecución y verificación reproducible',
      'Instalar requirements.txt, FFmpeg, eSpeak NG y DejaVu Sans. '
      'Ejecutar: python generar_video.py --benchmark --demo-music. '
      'Cambiar --workers para controlar el tamaño de los pools y --height 1280 para reducir el costo de render. '
      'Ejecutar las pruebas con python -m unittest discover -s tests -v. '
      'Inspeccionar pistas y duración con ffprobe y decodificar todo el MP4 con ffmpeg -v error -i salida/goku_narrado.mp4 -f null -. '
      'metadatos.json contiene las mediciones, los índices, los hilos y los intervalos que permiten revisar este informe. '
      'Las pruebas cubren correspondencia entre pares, extremos de transición, reloj PCM y recolección ordenada de tareas.')
    section('12. Enlace de YouTube',m['youtube'])
    section('13. Conclusión',
      'La solución aplica descomposición por datos y por escenas. El paralelismo del render se realiza mediante trabajadores Python '
      'que coordinan codificadores independientes; el ensamblaje final mantiene el orden narrativo. '
      'Se evita escribir concurrentemente en un único archivo y se usa una línea de tiempo común para audio y video. '
      'Los resultados medidos se distinguen de las expectativas teóricas: la concurrencia observada no se presenta como aceleración no medida.')
    section('Referencias',
      'Guías del curso conservadas en referencias/: “5 genera videos con IA e hilos.pdf” y “5 VIDEOS con IA.pdf”. '
      'Biblioteca estándar Python: https://docs.python.org/3/library/concurrent.futures.html . '
      'FFmpeg: https://ffmpeg.org/ffmpeg-formats.html#concat y https://ffmpeg.org/ffmpeg-filters.html . '
      'Edge TTS: https://github.com/rany2/edge-tts .')
    story.append(PageBreak());doc.add_page_break()
    section('Anexo. Capturas del video vertical',
      'Capturas extraídas del MP4 final. Cada pareja presenta la imagen anime suministrada y su versión realista correspondiente.')
    for j in range(0,len(samples),2):
        a,ia=samples[j];b,ib=samples[j+1]
        row=Table([[Image(str(caps/f'{a}.png'),width=185,height=329),Image(str(caps/f'{b}.png'),width=185,height=329)]],colWidths=[240,240])
        caption=f'Pareja {j//2+1}: {scenes[ia]["title"]}. Anime a la izquierda; realista a la derecha.'
        story.append(KeepTogether([row,Paragraph(escape(caption),styles['BodyText'])]))
        table=doc.add_table(rows=1,cols=2)
        for cell,name in zip(table.rows[0].cells,[a,b]):cell.paragraphs[0].add_run().add_picture(str(caps/f'{name}.png'),width=Inches(2.4))
        doc.add_paragraph(caption)
        md.extend([f'![Anime](capturas/{a}.png)',f'![Realista](capturas/{b}.png)',caption,''])
    doc.save(out/'informe.docx')
    SimpleDocTemplate(str(out/'informe.pdf'),title='Video con hilos - Computación Paralela',leftMargin=48,rightMargin=48,topMargin=42,bottomMargin=42).build(story)
    (out/'informe.md').write_text('\n'.join(md),encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'salida');p.add_argument('--youtube')
    a=p.parse_args();generar_informe(a.output,a.youtube)
